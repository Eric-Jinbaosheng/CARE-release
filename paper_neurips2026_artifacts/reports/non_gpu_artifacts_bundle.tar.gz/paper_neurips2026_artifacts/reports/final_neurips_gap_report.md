# Final NeurIPS Gap Report

| Item | Status | Evidence file | Action needed | Paper location |
|---|---|---|---|---|
| main 9-benchmark n=1000 table | DONE | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/tables/main_results_n1000.tex` | None | Main results section |
| TextVQA routed n=1000 | PARTIAL | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/reports/textvqa_routed_decision.md` | Run routed TextVQA n=1000 or keep focused-force-grid caveat | CF section caveat |
| TextVQA force-grid focused check | DONE | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/tables/cf_textvqa_focused.tex` | None | CF focused subsection |
| no_quality_gate / force_switch negative ablation | DONE | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/tables/cf_bad_ablation.tex` | None | CF negative ablations |
| NoCF component ablations | PARTIAL | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/tables/nocf_ablation_n200.tex` | Run ablation jobs; current table is mostly NA | NoCF ablations |
| bootstrap CI | DONE | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/tables/bootstrap_ci_main.tex` | None | Stats/robustness |
| compute/latency table | DONE | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/tables/compute_cost_table.tex` | None | Compute section |
| qualitative examples | DONE | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/reports/qualitative_examples.md` | None | Qualitative appendix |
| answer-space rules | DONE | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/reports/answer_space_rules.md` | None | Method appendix |
| second backbone | PARTIAL | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/reports/second_backbone_feasibility.md` | Run second-backbone n=200 jobs | Generalization appendix |
| anonymous reproducibility package | DONE | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/reproducibility/anonymize_for_neurips.sh` | None | Reproducibility |
| checklist notes | DONE | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/supplement/limitations_checklist_notes.md` | None | Checklist |
| limitations section | DONE | `/scratch/bj2410/peking/smolvlm2_paper/ets_clean/paper_neurips2026_artifacts/supplement/paper_patch_sections.tex` | None | Limitations |

Note: n=1000 ablation table may contain NA rows until GPU jobs finish.
